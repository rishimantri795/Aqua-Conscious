import React, { useEffect, useState, useContext } from 'react';
import { View, Text, Button, FlatList, StyleSheet, Pressable, Alert } from 'react-native';
import { CartContext } from '../CartContext';
import { getProducts } from '../services/ProductsService.js';
import {LinearGradient} from 'expo-linear-gradient';
export function Cart ({navigation}) {
const {items, getItemsCount, getTotalPrice} = useContext(CartContext);



const [productsData, setProductsData] = useState ([getProducts()]);

  function Totals() {
    let [total, setTotal] = useState(0);
    useEffect(() => {
      setTotal(getTotalPrice());
    });
    return (
       <View style={styles.cartLineTotal}>
          <Text style={[styles.lineLeft, styles.lineTotal]}>Total</Text>
          <Text style={styles.lineRight}>{total} Aqua Points </Text>
       </View>
    );
  }
function renderItem({item}) {
    return (
       <View style={styles.cartLine}>
          <Text style={styles.lineLeft}>{item.product.name} x {item.qty}</Text>
          <Text style={styles.lineRight}>{item.totalPrice} Aqua Points</Text>
          <Pressable>
          <Text onPress={() => deleteSelectedElement(item.product.id, item.product.name)} >
         X Remove </Text>
          </Pressable>
       </View>
    );
  }

const deleteSelectedElement = (id, name) => {
 
    Alert.alert(
      'Are You Sure Want To Delete Item = ' + name,
      'Select Below Options',
      [
        { text: 'Cancel', onPress: () => { }, style: 'cancel' },
        {
          text: 'OK', onPress: () => {
            // Filter Data 
            let arr = productsData.filter(function(item) {
            return item.id !== id
            })
            setProductsData(arr);
            //Updating List Data State with NEW Data.
          }
        },
      ])
  }

  return (
    <LinearGradient colors = {['#1EB5C6', '#445BCC']} style ={styles.container}>
    <FlatList
      style={styles.itemsList}
      contentContainerStyle={styles.itemsListContainer}
      data={items}
      renderItem={renderItem}
      keyExtractor={(item) => item.product.id.toString()}
      ListFooterComponent={Totals}
    />
    </LinearGradient>
  );
}
const styles = StyleSheet.create({
  cartLine: { 
    flexDirection: 'row',
  },
  cartLineTotal: { 
    flexDirection: 'row',
    borderTopColor: '#dddddd',
    borderTopWidth: 1
  },
  lineTotal: {
    fontWeight: 'bold',    
  },
  lineLeft: {
    fontSize: 20, 
    lineHeight: 40, 
    color:'white' 
  },
  lineRight: { 
    flex: 1,
    fontSize: 20, 
    fontWeight: 'bold',
    lineHeight: 40, 
    color:'white', 
    textAlign:'right',
  },
  itemsList: {
  },
  itemsListContainer: {
    paddingVertical: 8,
    marginHorizontal: 8,
  },
});